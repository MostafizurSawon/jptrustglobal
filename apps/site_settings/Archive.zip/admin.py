from django.contrib import admin
from .models import Contact, Testimonial

# Register your models here.
admin.site.register(Contact)
admin.site.register(Testimonial)
